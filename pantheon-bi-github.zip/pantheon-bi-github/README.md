# Pantheon BI — Faturamento AMHPDF

Dashboard financeiro premium da Pantheon, pronto para publicação gratuita no GitHub Pages ou Netlify.

## Arquivos

- `index.html` — página principal do BI.
- `assets/logo-pantheon.png` — logo da Pantheon.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta.
3. Vá em **Settings > Pages**.
4. Em **Build and deployment**, selecione:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
5. Clique em **Save**.

## Publicar no Netlify

1. Acesse o Netlify.
2. Clique em **Add new site > Deploy manually**.
3. Arraste a pasta ou o `.zip` deste projeto.
4. O site será publicado automaticamente.

## Observação

Este BI é estático. Para atualizar os dados, gere novamente o HTML com os CSVs atualizados e substitua o arquivo `index.html`.
